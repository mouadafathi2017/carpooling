package com.projetS3.tests;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.projetS3.dao.AdminDao;
import com.projetS3.dao.AdminDaoJdbc;
import com.projetS3.dao.ClientDao;
import com.projetS3.dao.ClientDaoJdbc;
import com.projetS3.dao.OffreCovoiturageDao;
import com.projetS3.dao.OffreCovoiturageDaoJdbc;
import com.projetS3.dao.OffreTransportDuBienDao;
import com.projetS3.dao.OffreTransportDuBienDaoJdbc;
import com.projetS3.dao.TransporteurDao;
import com.projetS3.dao.TransporteurDaoJdbc;
import com.projetS3.jpa.*;
import com.projetS3.utils.HibernateUtils;

public class Main {

	public static void main(String[] args) {
		
		Session session = HibernateUtils.getSession();
		//AdminDao admindao = new AdminDaoJdbc(session);
		/* //Compte
		Compte compte = new Compte();
		compte.setPassword("pass2");
		compte.setUsername("login2");
		//Admin
		Admin admin = new Admin("AFathi", "MOuad", "27/06/1994", "CB291085",
				"0645878386", "mouad.afathi@gmail.com", compte, "mouad_afathi_cb291085");
		
		admindao.insert(admin);
		session.close();
		*/
		/*ClientDao clientdao = new ClientDaoJdbc(session);
		Compte compte = new Compte("username1", "password","client");
		*/
		Compte compte1 = new Compte("username", "password","transporteur");
		//Client client = new Client("Aqil", "Ghada", "13/12/2000", "b123654", "0622332233",
		//		"ghadaaq@gmail.com", compte, TypePersonne.Physique, null);
		
		//clientdao.insert(client);
		List<Offre> list = new ArrayList<Offre>();
		Transporteur tr = new Transporteur("Arabi", "Asmaa", "1994-06-27", "CB291085", "0645878386",
						"otmane.ansari@usmba.ac.ma", compte1, TypePersonne.Physique, "Honda", list);
		TransporteurDao trdao = new TransporteurDaoJdbc(session);
		trdao.insert(tr);
		OffreTransportDuBien ofTB = new OffreTransportDuBien("Casa", "Fes", "2015-12-04","", "Desc", tr, null, 20, 60);
		OffreTransportDuBienDao offredao = new OffreTransportDuBienDaoJdbc(session);
		offredao.insert(ofTB);
		session.close();
		
	}

}
