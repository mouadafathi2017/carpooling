package com.projetS3.dao;

import java.util.List;

import com.projetS3.jpa.Compte;

public interface CompteDao {
	
	public boolean insert(Compte compte);
	public boolean update(Compte compte);
	public Compte select(int code);
	public Compte select(String login,String pass);
	public List<Compte> selectAll();
	public boolean delete(int code);
}
