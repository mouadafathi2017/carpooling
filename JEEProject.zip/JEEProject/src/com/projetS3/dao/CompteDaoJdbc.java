package com.projetS3.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.projetS3.jpa.Compte;
public class CompteDaoJdbc implements CompteDao {
	private Session session;

	public CompteDaoJdbc() {
		super();
	}

	public CompteDaoJdbc(Session session) {
		super();
		this.session = session;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	@Override
	public boolean insert(Compte compte) {
		
		try {
			Transaction t=session.beginTransaction();
			session.persist(compte);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}

	@Override
	public boolean update(Compte compte) {
		try {
			Transaction t=session.beginTransaction();
			  session.update(compte);
			  t.commit();
			  return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	   	  
		}
	@Override
	public Compte select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Compte where code_compte = :code");
		q.setString("code",""+code);
		Compte compte=(Compte)q.uniqueResult();
		t.commit();
		return compte;
	}

	@Override
	public List<Compte> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Compte");
		ArrayList<Compte> list=(ArrayList<Compte>)q.list();
		t.commit();
		return list;
	}

	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			Compte compte=select(code);
			session.delete(compte);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	@Override
	public Compte select(String login, String pass) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Compte where username='"+login+"' and password='"+pass+"'");
		System.out.println(q.getQueryString());
		Compte compte=(Compte)q.uniqueResult();
		t.commit();
		return compte;
	}
}
