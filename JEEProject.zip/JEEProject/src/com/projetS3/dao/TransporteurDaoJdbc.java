package com.projetS3.dao;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.projetS3.jpa.Transporteur;

public class TransporteurDaoJdbc implements TransporteurDao{
	
	private Session session;

	public TransporteurDaoJdbc() {
		super();
	}

	public TransporteurDaoJdbc(Session session) {
		super();
		this.session = session;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	@Override
	public boolean insert(Transporteur transporteur) {
		try {
			Transaction t=session.beginTransaction();
			session.persist(transporteur);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
	    }
	}

	@Override
	public boolean update(Transporteur transporteur) {
		try {
			Transaction t=session.beginTransaction();
			  session.update(transporteur);
			  t.commit();
			  return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public Transporteur select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Transporteur where code_personne = :code");
		q.setString("code",""+code);
		Transporteur transporteur =(Transporteur)q.uniqueResult();
		t.commit();
		return transporteur;
	}

	@Override
	public List<Transporteur> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Transporteur");
		ArrayList<Transporteur> list=(ArrayList<Transporteur>)q.list();
		t.commit();
		return list;
		}

	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			Transporteur transporteur=select(code);
			session.delete(transporteur);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
	@Override
	public Transporteur select(String key, int value) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Personne where "+ key +"= :code");
		q.setString("code",""+value);
		Transporteur transporteur=(Transporteur)q.uniqueResult();
		t.commit();
		return transporteur;
	}
}
