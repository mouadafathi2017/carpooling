package com.projetS3.dao;

import java.util.List;

import com.projetS3.jpa.Transporteur;

public interface TransporteurDao {
	
	public boolean insert(Transporteur transporteur);
	public boolean update(Transporteur transporteur);
	public Transporteur select(int code);
	public List<Transporteur> selectAll();
	public boolean delete(int code);
	public Transporteur select(String key, int value);
}
