package com.projetS3.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.projetS3.jpa.Admin;

public class AdminDaoJdbc implements AdminDao{

	private Session session;
	
	
	public AdminDaoJdbc() {
		super();
	}

	
	public AdminDaoJdbc(Session session) {
		super();
		this.session = session;
	}


	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	@Override
	public boolean insert(Admin admin) {
		
		 try {
			Transaction t=session.beginTransaction();
			session.persist(admin);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}

	@Override
	public boolean update(Admin admin) {
	   	  try {
	  		Transaction t=session.beginTransaction();
	  		  session.update(admin);
	  		  t.commit();
	  		  return true;
	  	} catch (HibernateException e) {
	  		// TODO Auto-generated catch block
	  		e.printStackTrace();
	  		return false;
	  	}
	}

	@Override
	public Admin select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Personne where code_personne= :code");
		q.setString("code",""+code);
		Admin admin=(Admin)q.uniqueResult();
		t.commit();
		return admin;
	}

	@Override
	public List<Admin> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Personne where DTYPE = 'Admin'");
		ArrayList<Admin> list=(ArrayList<Admin>)q.list();
		t.commit();
		return list;
	}

	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			Admin admin=select(code);
			session.delete(admin);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	@Override
	public Admin select(String key, String code)
	{
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Personne where "+key+ "= :code");
		q.setString("code",""+code);
		Admin admin=(Admin)q.uniqueResult();
		t.commit();
		return admin;
	}

}
