package com.projetS3.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.projetS3.jpa.Offre;
import com.projetS3.jpa.OffreTransportDuBien;

public class OffreTransportDuBienDaoJdbc implements OffreTransportDuBienDao{

	private Session session;

	public OffreTransportDuBienDaoJdbc() {
		super();
	}	
	public OffreTransportDuBienDaoJdbc(Session session) {
		super();
		this.session = session;
	}

	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}

	@Override
	public boolean insert(OffreTransportDuBien offreTransportDuBien) {
		try {
			Transaction t=session.beginTransaction();
			session.persist(offreTransportDuBien);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean update(OffreTransportDuBien offreTransportDuBien) {
		try {
		Transaction t=session.beginTransaction();
		  session.update(offreTransportDuBien);
		  t.commit();
		  return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return false;
	}
	}

	@Override
	public OffreTransportDuBien select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Offre where code_offre = :code");
		q.setString("code",""+code);
		OffreTransportDuBien offreTransportDuBien=(OffreTransportDuBien)q.uniqueResult();
		t.commit();
		return offreTransportDuBien;
	}

	@Override
	public List<Offre> selectAll() {
		
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Offre where DTYPE = OffreTransportDuBien");
		ArrayList<Offre> list=(ArrayList<Offre>)q.list();
		t.commit();
		return list;
		
	}

	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			OffreTransportDuBien offreTransportDuBien=select(code);
			session.delete(offreTransportDuBien);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	@Override
	public List<Offre> select(String villedep, String villedest, String date, String type) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Offre where villeDepart = '"+villedep+"' and villeDestination = '"+villedest+"' and dateVoyage = '"+date+"'");
		System.out.println(q.toString());
		List<Offre> list=(ArrayList<Offre>)q.list();
		t.commit();
		return list;
	}
	@Override
	public List<Offre> selectAllById(int code)
	{
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Offre where offre_transporteur_id = "+code);
		System.out.println(q.toString());
		List<Offre> list=(ArrayList<Offre>)q.list();
		t.commit();
		return list;
	}

}
