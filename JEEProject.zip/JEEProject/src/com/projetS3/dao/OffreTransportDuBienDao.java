package com.projetS3.dao;

import java.util.List;

import com.projetS3.jpa.Offre;
import com.projetS3.jpa.OffreTransportDuBien;

public interface OffreTransportDuBienDao {
	public boolean insert(OffreTransportDuBien offreTransportDuBien);
	public boolean update(OffreTransportDuBien offreTransportDuBien);
	public OffreTransportDuBien select(int code);
	public List<Offre> selectAll();
	public boolean delete(int code);
	public List<Offre> select(String villedep, String villedest, String date, String type);
	public List<Offre> selectAllById(int code);
}
