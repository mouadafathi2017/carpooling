package com.projetS3.dao;

import java.util.List;

import com.projetS3.jpa.*;

public interface OffreCovoiturageDao {
	public boolean insert(OffreCovoiturage OffreCovoiturage);
	public boolean update(OffreCovoiturage OffreCovoiturage);
	public OffreCovoiturage select(int code);
	public List<Offre> selectAll();
	public boolean delete(int code);
	public List<Offre> select(String villedep, String villedest, String date, String type);
	public List<Offre> selectAllById(int code);
}
