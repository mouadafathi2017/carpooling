package com.projetS3.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.projetS3.jpa.Client;

public class ClientDaoJdbc implements ClientDao {
	private Session session;

	public ClientDaoJdbc() {
		super();
	}

	public ClientDaoJdbc(Session session) {
		super();
		this.session = session;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	
	public boolean insert(Client client) {
		try {
			Transaction t=session.beginTransaction();
			session.persist(client);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
	    }
   }
	
	public boolean update(Client client) {
		 try {
				Transaction t=session.beginTransaction();
				  session.update(client);
				  t.commit();
				  return true;
			} catch (HibernateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
	}
	@Override
	public Client select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Personne where code_personne= :code");
		q.setString("code",""+code);
		Client client=(Client)q.uniqueResult();
		t.commit();
		return client;
	}

	@Override
	public List<Client> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Personne where DTYPE = 'Client'");
		ArrayList<Client> list=(ArrayList<Client>)q.list();
		t.commit();
		return list;
		}

	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			Client client=select(code);
			session.delete(client);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public Client select(String key, int value) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Personne where "+ key +"= :code");
		q.setString("code",""+value);
		Client client=(Client)q.uniqueResult();
		t.commit();
		return client;
	}	
}

