package com.projetS3.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.projetS3.jpa.Offre;
import com.projetS3.jpa.OffreCovoiturage;
public class OffreCovoiturageDaoJdbc implements OffreCovoiturageDao {
	
	private Session session;

	public OffreCovoiturageDaoJdbc() {
		super();
	}

	public OffreCovoiturageDaoJdbc(Session session) {
		super();
		this.session = session;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	@Override
	public boolean insert(OffreCovoiturage offre) {
		try {
			Transaction t=session.beginTransaction();
			session.persist(offre);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean update(OffreCovoiturage offre) {
		try {
			Transaction t=session.beginTransaction();
			  session.update(offre);
			  t.commit();
			  return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public OffreCovoiturage select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Offre where code_offre = :code");
		q.setString("code",""+code);
		OffreCovoiturage offre=(OffreCovoiturage)q.uniqueResult();
		t.commit();
		return offre;
	}

	@Override
	public List<Offre> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Offre where DTYPE = OffreCovoiturage");
		ArrayList<Offre> list=(ArrayList<Offre>)q.list();
		System.out.println("here");
		t.commit();
		return list;
	}

	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			OffreCovoiturage offre=select(code);
			session.delete(offre);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}

	@Override
	public List<Offre> select(String villedep, String villedest, String date, String type) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Offre where villeDepart = '"+villedep+"' and villeDestination = '"+villedest+"' and dateVoyage = '"+date+"'");
		System.out.println("here");
		List<Offre> list=(ArrayList<Offre>)q.list();
		t.commit();
		return list;
	}
	
	@Override
	public List<Offre> selectAllById(int code)
	{
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Offre where offre_transporteur_id = "+code);
		System.out.println("here");
		List<Offre> list=(ArrayList<Offre>)q.list();
		t.commit();
		return list;
	}
}
