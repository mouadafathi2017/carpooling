package com.projetS3.dao;

import java.util.List;

import com.projetS3.jpa.Client;
import com.projetS3.jpa.Compte;

public interface ClientDao {

	public boolean insert(Client client);
	public boolean update(Client client);
	public Client select(int code);
	public Client select(String key, int value);
	public List<Client> selectAll();
	public boolean delete(int code);
	
}
