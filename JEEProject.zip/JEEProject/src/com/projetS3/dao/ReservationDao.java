package com.projetS3.dao;

import java.util.List;

import com.projetS3.jpa.Reservation;

public interface ReservationDao {

	public boolean insert(Reservation reservation);
	public boolean update(Reservation reservation);
	public Reservation select(int code);
	public List<Reservation> selectAll();
	public boolean delete(int code);
	public List<Reservation> selectByClientId(int code);
}
