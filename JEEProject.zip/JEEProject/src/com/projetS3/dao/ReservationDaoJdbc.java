package com.projetS3.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.projetS3.jpa.Reservation;

public class ReservationDaoJdbc implements ReservationDao{
	
	private Session session;
	
	public ReservationDaoJdbc() {
		super();
	}
	
	public ReservationDaoJdbc(Session session) {
		super();
		this.session = session;
	}
	
	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	@Override
	public boolean insert(Reservation reservation) {
		try {
			Transaction t=session.beginTransaction();
			session.persist(reservation);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean update(Reservation reservation) {
		try {
		Transaction t=session.beginTransaction();
		  session.update(reservation);
		  t.commit();
		  return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return false;
	}
	}

	@Override
	public Reservation select(int code) {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Reservation where code_reservation = :code");
		System.out.println(code);
		q.setString("code",""+code);
		Reservation reservation=(Reservation)q.uniqueResult();
		t.commit();
		return reservation;
	}

	@Override
	public List<Reservation> selectAll() {
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Reservation");
		ArrayList<Reservation> list=(ArrayList<Reservation>)q.list();
		t.commit();
		return list;
	}

	@Override
	public boolean delete(int code) {
		try {
			Transaction t=session.beginTransaction();
			Reservation reservation=select(code);
			session.delete(reservation);
			t.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
	@Override
	public List<Reservation> selectByClientId(int code)
	{
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("from Reservation where reservation_client_id = :code");
		q.setString("code", ""+code);
		ArrayList<Reservation> list=(ArrayList<Reservation>)q.list();
		t.commit();
		return list;
	}

}
