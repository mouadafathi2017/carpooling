package com.projetS3.dao;

import java.util.List;

import com.projetS3.jpa.Admin;

public interface AdminDao {
	public boolean insert(Admin admin);
	public boolean update(Admin admin);
	public Admin select(int code);
	public Admin select(String key, String code);
	public List<Admin> selectAll();
	public boolean delete(int code);
}
