package com.projetS3.jpa;

public enum TypePersonne {
Physique,Moral;
}
