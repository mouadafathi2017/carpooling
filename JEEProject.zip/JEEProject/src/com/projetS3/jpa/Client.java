package com.projetS3.jpa;

import java.util.List;

import javax.persistence.*;

@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@Table(name="client")
public class Client extends Personne{

	@Enumerated(EnumType.STRING)
	private TypePersonne typePersonne;
	@OneToMany(mappedBy="client",cascade={CascadeType.ALL})
	@Column(name="reservation")
	private List<Reservation> reservations;
	public Client() {
		super();
	}
	public Client(String nom, String prenom, String dateNaissance, String cin, String telephone, String email,
			Compte compte, TypePersonne typePersonne, List<Reservation> reservations) {
		super(nom, prenom, dateNaissance, cin, telephone, email, compte);
		this.typePersonne = typePersonne;
		this.reservations = reservations;
	}
	public TypePersonne getTypePersonne() {
		return typePersonne;
	}
	public void setTypePersonne(TypePersonne typePersonne) {
		this.typePersonne = typePersonne;
	}
	public List<Reservation> getReservations() {
		return reservations;
	}
	public void setReservations(List<Reservation> reservations) {
		this.reservations = reservations;
	}
}
