package com.projetS3.jpa;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="offre")
public class Offre {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="code_offre")
	private int id;
	@Column(name="villeDepart")
	private String villeDeaprt;
	@Column(name="villeDestination")
	private String villeDestination;
	@Column(name="dateVoyage")
	private String dateVoyage;
	@Column(name="heure")
	private String heure;
	@Column(name="description")
	@Lob
	private String description;
	@ManyToOne()
	@JoinColumn(name="offre_transporteur_id")
	private Transporteur transporteur;
	@OneToMany(mappedBy="offre",cascade={CascadeType.ALL})
	@Column(name="reservationOf")
	private List<Reservation> reservations;
	
	public Offre() {
		super();
	}

	public Offre(String villeDeaprt, String villeDestination, String dateVoyage,String heure, String description,
			Transporteur transporteur, List<Reservation> reservations) {
		super();
		this.villeDeaprt = villeDeaprt;
		this.villeDestination = villeDestination;
		this.dateVoyage = dateVoyage;
		this.heure = heure;
		this.description = description;
		this.transporteur = transporteur;
		this.reservations = reservations;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getVilleDeaprt() {
		return villeDeaprt;
	}

	public void setVilleDeaprt(String villeDeaprt) {
		this.villeDeaprt = villeDeaprt;
	}

	public String getVilleDestination() {
		return villeDestination;
	}

	public void setVilleDestination(String villeDestination) {
		this.villeDestination = villeDestination;
	}

	public String getDateVoyage() {
		return dateVoyage;
	}

	public void setDateVoyage(String dateVoyage) {
		this.dateVoyage = dateVoyage;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Transporteur getTransporteur() {
		return transporteur;
	}

	public void setTransporteur(Transporteur transporteur) {
		this.transporteur = transporteur;
	}

	public List<Reservation> getReservations() {
		return reservations;
	}

	public void setReservations(List<Reservation> reservations) {
		this.reservations = reservations;
	}

	public String getHeure() {
		return heure;
	}

	public void setHeure(String heure) {
		this.heure = heure;
	}
	
}
