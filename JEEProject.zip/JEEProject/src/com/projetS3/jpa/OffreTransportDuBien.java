package com.projetS3.jpa;

import java.util.LinkedList;

import javax.persistence.*;

@Entity
@Table(name="OffreTransportDuBien")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
public class OffreTransportDuBien extends Offre{
	
	@Column(name="prixParKilo")
	private float prixParKilo;
	@Column(name="maxKilos")
	private float maxKilos;
	
	
	
	public OffreTransportDuBien() {
		super();
	}
	

	public OffreTransportDuBien(String villeDeaprt, String villeDestination, String dateVoyage, String heure,
			String description, Transporteur transporteur, LinkedList<Reservation> reservations, float prixParKilo,
			int maxKilos) {
		super(villeDeaprt, villeDestination, dateVoyage, heure, description, transporteur, reservations);
		this.prixParKilo = prixParKilo;
		this.maxKilos = maxKilos;
	}



	public float getPrixParKilo() {
		return prixParKilo;
	}
	public void setPrixParKilo(float prixParKilo) {
		this.prixParKilo = prixParKilo;
	}
	public float getMaxKilos() {
		return maxKilos;
	}
	public void setMaxKilos(float maxKilos) {
		this.maxKilos = maxKilos;
	}
	

}
