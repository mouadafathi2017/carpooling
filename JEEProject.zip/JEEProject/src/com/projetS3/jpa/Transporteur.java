package com.projetS3.jpa;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="transporteur")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
public class Transporteur extends Personne{
	
	@Enumerated(EnumType.STRING)
	private TypePersonne typePersonne;
	@Column(name="typeVehicule")
	private String typeVehicule;
	@OneToMany(mappedBy="transporteur",cascade={CascadeType.ALL})
	private List<Offre> offres;
	public Transporteur() {
		super();
	}
	public Transporteur(String nom, String prenom, String dateNaissance, String cin, String telephone,
			String email, Compte compte, TypePersonne typePersonne, String typeVehicule,
			List<Offre> offres) {
		super(nom, prenom, dateNaissance, cin, telephone, email, compte);
		this.typePersonne = typePersonne;
		this.typeVehicule = typeVehicule;
		this.offres = offres;
	}
	public TypePersonne getTypePersonne() {
		return typePersonne;
	}
	public void setTypePersonne(TypePersonne typePersonne) {
		this.typePersonne = typePersonne;
	}
	public String getTypeVehicule() {
		return typeVehicule;
	}
	public void setTypeVehicule(String typeVehicule) {
		this.typeVehicule = typeVehicule;
	}
	public List<Offre> getOffres() {
		return offres;
	}
	public void setOffres(List<Offre> offres) {
		this.offres = offres;
	}
	

}
