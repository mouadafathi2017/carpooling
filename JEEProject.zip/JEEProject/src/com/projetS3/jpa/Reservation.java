package com.projetS3.jpa;

import javax.persistence.*;

@Entity
@Table(name="reservation")
public class Reservation {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="code_reservation")
	private int id;
	@Column(name="confime")
	private String confirmed;
	@ManyToOne()
	@JoinColumn(name="reservation_offre_id")
	private Offre offre;
	public String isConfirmed() {
		return confirmed;
	}
	public void setConfirmed(String confirmed) {
		this.confirmed = confirmed;
	}
	@ManyToOne()
	@JoinColumn(name="reservation_client_id")
	private Client client;
	public Reservation() {
		super();
	}
	public Reservation(Offre offre, Client client) {
		super();
		this.confirmed = "/";
		this.offre = offre;
		this.client = client;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Offre getOffre() {
		return offre;
	}
	public void setOffre(Offre offre) {
		this.offre = offre;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
}
