package com.projetS3.jpa;

import java.util.LinkedList;

import javax.persistence.*;

@Entity
@Table(name="OffreCovoiturage")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
public class OffreCovoiturage extends Offre{

	@Column(name="prixParPersonne")
	private float prixParPersonne;
	@Column(name="maxPersonne")
	private int maxPersonne;

	public OffreCovoiturage() {
		super();
	}

	public OffreCovoiturage(String villeDeaprt, String villeDestination, String dateVoyage, String heure, String description,
			Transporteur transporteur, LinkedList<Reservation> reservations, float prixParPersonne,
			int maxPersonne) {
		super(villeDeaprt,villeDestination, dateVoyage, heure, description, transporteur, reservations);
		this.prixParPersonne = prixParPersonne;
		this.maxPersonne = maxPersonne;
	}

	public float getPrixParPersonne() {
		return prixParPersonne;
	}
	public void setPrixParPersonne(float prixParPersonne) {
		this.prixParPersonne = prixParPersonne;
	}
	public int getMaxPersonne() {
		return maxPersonne;
	}
	public void setMaxPersonne(int maxPersonne) {
		this.maxPersonne = maxPersonne;
	}
}
