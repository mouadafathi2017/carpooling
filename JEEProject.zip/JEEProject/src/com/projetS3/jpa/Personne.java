package com.projetS3.jpa;

import javax.persistence.*;

@Entity
@Table(name="personne")
public class Personne {
	
	// Attributs
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="code_personne")
	private int id;
	@Column(name="nom_personne")
	private String nom;
	@Column(name="prenom_personne")
	private String prenom;
	@Column(name="dateNaissance_personne")
	private String dateNaissance;
	@Column(name="cin_personne")
	private String cin;
	@Column(name="telephone_personne")
	private String telephone;
	@Column(name="email_personne")
	private String email;
	@OneToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="personne_compteId",referencedColumnName="code_compte")
	private Compte compte;
	
	
	public Personne() {
		super();
	}
	public Personne(String nom, String prenom, String dateNaissance, String cin, String telephone, String email,
			Compte compte) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.dateNaissance = dateNaissance;
		this.cin = cin;
		this.telephone = telephone;
		this.email = email;
		this.compte = compte;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Compte getCompte() {
		return compte;
	}
	public void setComptes(Compte compte) {
		this.compte = compte;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getDateNaissance() {
		return dateNaissance;
	}
	public void setDateNaissance(String dateNaissance) {
		this.dateNaissance = dateNaissance;
	}
	public String getCin() {
		return cin;
	}
	public void setCin(String cin) {
		this.cin = cin;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String toString()
	{
		return this.nom+" "+this.prenom;
	}
}
