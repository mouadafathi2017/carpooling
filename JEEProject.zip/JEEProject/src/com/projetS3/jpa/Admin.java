package com.projetS3.jpa;


import javax.persistence.*;

@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@Table(name="admin")
public class Admin extends Personne{

	@Column(name="codeSecurite")
	private String codeSecurite;
	
	
	
	public Admin() {
		super();
	}
	
	public Admin(String nom, String prenom, String dateNaissance, String cin, String telephone, String email,
			Compte compte, String codeSecurite) {
		super(nom, prenom, dateNaissance, cin, telephone, email, compte);
		this.codeSecurite = codeSecurite;
	}

	public String getCodeSecurite() {
		return codeSecurite;
	}
	public void setCodeSecurite(String codeSecurite) {
		this.codeSecurite = codeSecurite;
	}
	
	
}
