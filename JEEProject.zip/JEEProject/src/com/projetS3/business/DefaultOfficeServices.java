package com.projetS3.business;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;

import com.projetS3.dao.*;
import com.projetS3.jpa.*;

public class DefaultOfficeServices implements OfficeServices{

	private AdminDao admindao;
	private ClientDao clientdao;
	private CompteDao comptedao;
	private OffreCovoiturageDao offreCovoituragedao;
	private OffreTransportDuBienDao offreTransportDuBiendao;
	private ReservationDao reservationdao;
	private TransporteurDao transporteurdao;
	
	public DefaultOfficeServices() {
		super();
	}
	

	public DefaultOfficeServices(AdminDao admindao, ClientDao clientdao, CompteDao comptedao,
			OffreCovoiturageDao offreCovoituragedao, OffreTransportDuBienDao offreTransportDuBiendao,
			ReservationDao reservationdao, TransporteurDao transporteurdao) {
		super();
		this.admindao = admindao;
		this.clientdao = clientdao;
		this.comptedao = comptedao;
		this.offreCovoituragedao = offreCovoituragedao;
		this.offreTransportDuBiendao = offreTransportDuBiendao;
		this.reservationdao = reservationdao;
		this.transporteurdao = transporteurdao;
	}


	public AdminDao getAdmindao() {
		return admindao;
	}



	public void setAdmindao(AdminDao admindao) {
		this.admindao = admindao;
	}



	public ClientDao getClientdao() {
		return clientdao;
	}



	public void setClientdao(ClientDao clientdao) {
		this.clientdao = clientdao;
	}



	public CompteDao getComptedao() {
		return comptedao;
	}



	public void setComptedao(CompteDao comptedao) {
		this.comptedao = comptedao;
	}



	public OffreCovoiturageDao getOffreCovoituragedao() {
		return offreCovoituragedao;
	}



	public void setOffreCovoituragedao(OffreCovoiturageDao offreCovoituragedao) {
		this.offreCovoituragedao = offreCovoituragedao;
	}



	public OffreTransportDuBienDao getOffreTransportDuBiendao() {
		return offreTransportDuBiendao;
	}



	public void setOffreTransportDuBiendao(OffreTransportDuBienDao offreTransportDuBiendao) {
		this.offreTransportDuBiendao = offreTransportDuBiendao;
	}



	public ReservationDao getReservationdao() {
		return reservationdao;
	}



	public void setReservationdao(ReservationDao reservationdao) {
		this.reservationdao = reservationdao;
	}



	public TransporteurDao getTransporteurdao() {
		return transporteurdao;
	}



	public void setTransporteurdao(TransporteurDao transporteurdao) {
		this.transporteurdao = transporteurdao;
	}



	@Override
	public Client authentificationClient(String username, String password) {
		Compte compte = comptedao.select(username, password);
		if(compte != null && compte.getType().equals("client"))
			return clientdao.select("personne_compteId", compte.getId());
		else
			return null;
	}
	
	@Override
	public Transporteur authentificationTransporteur(String username, String password) {
		Compte compte = comptedao.select(username, password);
		if(compte != null && compte.getType().equals("transporteur"))
			return transporteurdao.select("personne_compteId", compte.getId());
		else
			return null;
	}
	
	@Override
	public List<Offre> listerOffreClient(String villedep, String villedest, String type, String date)
	{
		System.out.println(type);
		if(type.equals("covoiturage"))
			return offreCovoituragedao.select(villedep, villedest, date, type);
		else
			return offreTransportDuBiendao.select(villedep, villedest, date, type);
	}
	@Override
	public List<Offre> listerOffres(String type)
	{
		if(type.equals("covoiturage"))
			return offreCovoituragedao.selectAll();
		else
			return offreTransportDuBiendao.selectAll();
	}
	
	@Override
	public boolean nouvelleReservation(int codeOffre, Client client, String type)
	{
		try {
			Offre offre;
			if(type.equals("covoiturage"))
				offre = offreCovoituragedao.select(codeOffre);
			else
				offre = offreTransportDuBiendao.select(codeOffre);
			Reservation reservation = new Reservation(offre, client);
			reservationdao.insert(reservation);
			return true;
		} catch (HibernateException e) {
			System.out.println(e.getMessage());
			return false;
		}
	}
	@Override
	public List<Reservation> listerReservationClient(int codeClient)
	{
		return reservationdao.selectByClientId(codeClient);
	}


	@Override
	public boolean modifierCompteClient(Compte compte) {
		try {
			comptedao.update(compte);
			return true;
		} catch (HibernateException e) {
			System.out.println(e.getMessage());
			return false;
		}
	}
	
	@Override
	public void insererNewOffer(String villedep, String villedest, String type, String date, String time, String maxPersonne, String prixParPersonne, String maxKilos, String prixParKilo, String desc, Transporteur carrier){
   	 OffreCovoiturage offrecovoiturage=new OffreCovoiturage();
        OffreTransportDuBien offreTransportDuBien =new OffreTransportDuBien();
   	if(type.equals("covoiturage")){
   		offrecovoiturage.setHeure(time);
   		offrecovoiturage.setVilleDeaprt(villedep);
   	   offrecovoiturage.setVilleDestination(villedest);
   	   offrecovoiturage.setDateVoyage(date);
   	   offrecovoiturage.setMaxPersonne(Integer.parseInt(maxPersonne));
   	   offrecovoiturage.setPrixParPersonne(Float.parseFloat(prixParPersonne));
   	   offrecovoiturage.setTransporteur(carrier);
   	   offrecovoiturage.setDescription(desc);
   	   offreCovoituragedao.insert(offrecovoiturage);
   	}
   	if(type.equals("bien")){
   		offreTransportDuBien.setDescription(desc);
   		offreTransportDuBien.setHeure(time);
   		offreTransportDuBien.setVilleDeaprt(villedep);
   		offreTransportDuBien.setVilleDestination(villedest);
   		offreTransportDuBien.setDateVoyage(date);
   		offreTransportDuBien.setMaxKilos(Float.parseFloat(maxKilos));
   		offreTransportDuBien.setPrixParKilo(Float.parseFloat(prixParKilo));
   		offreTransportDuBien.setTransporteur(carrier);
   		offreTransportDuBiendao.insert(offreTransportDuBien);
   	}
   }
	
	@Override
	public void insererNewCarrier(String nom, String prenom, String dateNaissance, String cin, String telephone,
			String email, String typePersonne, String typeVehicule,String username,String password){
		
		Compte compte = new Compte(username, password, "transporteur");
		List<Offre> offres = new ArrayList<Offre>();
		TypePersonne type;
		if(typePersonne.equals("M")){
    		type = TypePersonne.Moral;
    		}else{
    			type = TypePersonne.Physique;
    		}
    	Transporteur carrier = new Transporteur(nom, prenom, dateNaissance, cin, telephone, email, compte, type, typeVehicule, offres);
    	transporteurdao.insert(carrier);
    	  }
	@Override
	public void insererNewClient(String nom, String prenom, String dateNaissance, String cin, String telephone,
			String email, String typePersonne, String username,String password){
		Compte compte = new Compte(username, password, "client");
		TypePersonne type;
    	if(typePersonne.equals("M")){
    		type = TypePersonne.Moral;
    		}else{
    			type = TypePersonne.Physique;
    		}
    	List<Reservation> reservations = new ArrayList<Reservation>();
    	Client client = new Client(nom, prenom, dateNaissance, cin, telephone, email, compte, type, reservations);
    	clientdao.insert(client);
	}
	
	@Override
	public Admin authentificationAdmin(String username, String password)
	{
		Compte compte = comptedao.select(username, password);
		if(compte != null && compte.getType().equals("admin"))
			return admindao.select("personne_compteId", ""+compte.getId());
		else
			return null;
	}
	@Override
	public List<Reservation> ListerReservationCarrier(int codeT)
	{
		List<Reservation> list = reservationdao.selectAll();
		List<Reservation> list1 = new ArrayList<Reservation>();
		for(Reservation r : list)
		{
			if(r.getOffre().getTransporteur().getId() == codeT)
				list1.add(r);
		}
		return list1;
	}
	@Override
	public List<Offre> listerOffresCarrier(int code)
	{
		return offreTransportDuBiendao.selectAllById(code);
	}
	
	@Override
	public void supprimerOffreCarrier(int code, String type)
	{
		if(type.equals("C"))
			offreCovoituragedao.delete(code);
		else
			offreTransportDuBiendao.delete(code);
	}
	@Override
	public boolean updateCarrierAcc(Compte compte)
	{
		try{
			return comptedao.update(compte);
		}
		catch(HibernateException e){
			return false;
		}
	}
	
	@Override
	public Offre getOffer(int code, String type)
	{
		if(type.equals("C")){
			System.out.println(code+type);
			return offreCovoituragedao.select(code);
		}else
			return offreTransportDuBiendao.select(code);
	}
	@Override
	public boolean updateOffer(Offre offre)
	{
		try{
			if(offre.getClass() == com.projetS3.jpa.OffreCovoiturage.class)
				offreCovoituragedao.update((OffreCovoiturage)offre);
			else
				offreTransportDuBiendao.update((OffreTransportDuBien)offre);
			return true;
		}catch(HibernateException e){
			return false;
		}
	}
	@Override
	public boolean acceptReservation(int code)
	{
		Reservation reservation = reservationdao.select(code);
		reservation.setConfirmed("oui");
		try {
			reservationdao.update(reservation);
			return true;
		} catch (HibernateException e) {
			return false;
		}
	}
	@Override
	public boolean rejectReservation(int code)
	{
		Reservation reservation = reservationdao.select(code);
		reservation.setConfirmed("non");
		try {
			reservationdao.update(reservation);
			return true;
		} catch (HibernateException e) {
			return false;
		}
	}
	@Override
	public boolean annulerReservation(int code)
	{
		try {
			reservationdao.delete(code);
			return true;
		} catch (HibernateException e) {
			return false;
		}
	}
	@Override
	public Reservation getReservation(int code)
	{
			return reservationdao.select(code);
	}
	@Override
	public Client getClient(int code)
	{
		return clientdao.select(code);
	}
	
	@Override
	public List<Offre> afficherOffreCovoiturage(){
	    	
	    	return offreCovoituragedao.selectAll();
	    		
	    }
	 public OffreCovoiturage afficheOffreCovoiturage(int code){
	    	
	    	return offreCovoituragedao.select(code);
	    		
	    }
	    public List<Offre> afficherOffreTransport(){
	    		return offreTransportDuBiendao.selectAll();
	    }
	    public List<Client> afficherClient(){
			return clientdao.selectAll();
			
	}
	public List<Transporteur> afficherTransporteur(){
		
		return transporteurdao.selectAll();
			
	} 
	
	public void deleteOffretransport(int code){
		offreTransportDuBiendao.delete(code);
		}
		
	public void deleteOffreCovoiturage(int code){
		offreCovoituragedao.delete(code);
		}
	public void deleteClient(int code){
		clientdao.delete(code);
		}
	public void deleteTransporteur(int code){
		transporteurdao.delete(code);
		}  
	public void updateOffreCovoiturage(OffreCovoiturage offre){
		 offreCovoituragedao.update(offre);
		
	}  
	public Admin afficheAdmin(int code){
		return  admindao.select(code);
			}
	
	public void ModifierProfil(Admin adm){
		 admindao.update(adm);
		
	}
	public void ModifierCompte(Compte cmp){
		 comptedao.update(cmp);
		
	}
	public Compte afficheCompte(int code){
		return  comptedao.select(code);
			}
	}
	
