package com.projetS3.business;

import java.util.List;

import com.projetS3.jpa.*;

public interface OfficeServices {

	public Client authentificationClient(String username,String password);
	public Transporteur authentificationTransporteur(String username,String password);
	public List<Offre> listerOffreClient(String villedep, String villedest, String date, String type);
	public boolean nouvelleReservation(int codeOffre, Client client, String type);
	public List<Reservation> listerReservationClient(int codeClient);
	public boolean modifierCompteClient(Compte compte);
	public List<Offre> listerOffres(String type);
	public void insererNewOffer(String villedep, String villedest, String type, String date, String time, 
			String maxPersonne, String prixParPersonne, 
			String maxKilos, String prixParKilo, String desc, Transporteur carrier);
	public void insererNewCarrier(String nom, String prenom, String dateNaissance, String cin, String telephone,
			String email, String typePersonne, String typeVehicule,String username,String password);
	public void insererNewClient(String nom, String prenom, String dateNaissance, String cin, String telephone,
			String email, String typePersonne, String username,String password);
	public Admin authentificationAdmin(String username, String password);
	public List<Reservation> ListerReservationCarrier(int codeT);
	public boolean updateCarrierAcc(Compte compte);
	public List<Offre> listerOffresCarrier(int code);
	public void supprimerOffreCarrier(int code, String type);
	public Offre getOffer(int code, String type);
	public boolean updateOffer(Offre offre);
	public boolean acceptReservation(int code);
	public boolean rejectReservation(int code);
	public boolean annulerReservation(int code);
	public Reservation getReservation(int code);
	public Client getClient(int code);
	public List<Offre>afficherOffreCovoiturage();
	public OffreCovoiturage afficheOffreCovoiturage(int code);
	public List<Offre> afficherOffreTransport();
	public List<Client> afficherClient();
	public List<Transporteur> afficherTransporteur();
	public void deleteOffretransport(int code);
	public void deleteOffreCovoiturage(int code);
	public void deleteClient(int code);
	public void deleteTransporteur(int code);
	public  void updateOffreCovoiturage(OffreCovoiturage offre);
	public void ModifierProfil(Admin adm);
	public Admin afficheAdmin(int code);
	public Compte afficheCompte(int code);
	public void ModifierCompte(Compte cmp);
}
