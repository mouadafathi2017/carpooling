package com.projetS3.web.actions;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.projetS3.business.OfficeServices;
import com.projetS3.jpa.Offre;
import com.projetS3.jpa.Reservation;

public class MailAction extends Action{

	private String to;
	
	public MailAction()
	{
		this.to = "mouad.afathi@um5s.net.ma";
	}
	public MailAction(OfficeServices officeservices) {
		super(officeservices);
		this.to = "mouad.afathi@um5s.net.ma";
	}
	public void send()
	{
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", "smtp.gmail.com");
	    properties.put("mail.smtp.starttls.enable","true"); 
	    properties.put("mail.smtp.EnableSSL.enable","true");
	    properties.put("mail.smtp.auth", "true");
	    properties.put("mail.smtp.port", 587);
	      
	      // Get the default Session object.
	      Session session = Session.getDefaultInstance(properties);

	      try{
	         // Create a default MimeMessage object.
	         MimeMessage message = new MimeMessage(session);

	         // Set From: header field of the header.
	         message.setFrom(new InternetAddress((String)getRequest().getParameter("email")));

	         // Set To: header field of the header.
	         message.addRecipient(Message.RecipientType.TO,
	                                  new InternetAddress(to));

	         // Set Subject: header field
	         message.setSubject((String)getRequest().getParameter("subject"));

	         // Now set the actual message
	         message.setText("Email : "+getRequest().getParameter("email")+"\n\n"+(String)getRequest().getParameter("message")+"\n\nName : "+(String)getRequest().getParameter("name"));

	         // Send message
	         Transport.send(message,"email","password");
	         System.out.println("Sent message successfully....");
	      }catch (MessagingException mex) {
	         mex.printStackTrace();
	      }
}
	public void confirmReservation(String email)
	{
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", "smtp.gmail.com");
	    properties.put("mail.smtp.starttls.enable","true"); 
	    properties.put("mail.smtp.EnableSSL.enable","true");
	    properties.put("mail.smtp.auth", "true");
	    properties.put("mail.smtp.port", 587);
	    
	    Session session = Session.getDefaultInstance(properties);
	    
	    try {
	    	
	    	MimeMessage message = new MimeMessage(session);
	    	message.setFrom(new InternetAddress("mouad.afathi@um5s.com"));
	    	message.addRecipient(Message.RecipientType.TO,
                    new InternetAddress(email));
	    	message.setSubject("Confimation de votre réservation");
	    	message.setText("Votre reservation a été confirmé. Pour plus d'information veuillez vérifier vos réservations sur le site.\nMerci.\nCordialement.");
	    	Transport.send(message,"mouad.afathi@um5s.net.ma","king-flow");
	    	System.out.println("Sent message successfully....");
		} catch (MessagingException mex) {
			mex.printStackTrace();
		}
	}
	public void rejectReservation(String email)
	{
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", "smtp.gmail.com");
	    properties.put("mail.smtp.starttls.enable","true"); 
	    properties.put("mail.smtp.EnableSSL.enable","true");
	    properties.put("mail.smtp.auth", "true");
	    properties.put("mail.smtp.port", 587);
	    
	    Session session = Session.getDefaultInstance(properties);
	    
	    try {
	    	
	    	MimeMessage message = new MimeMessage(session);
	    	message.setFrom(new InternetAddress("mouad.afathi@um5s.com"));
	    	message.addRecipient(Message.RecipientType.TO,
                    new InternetAddress(email));
	    	message.setSubject("Confimation de votre réservation");
	    	message.setText("Votre reservation a été rejetée. Pour plus d'information veuillez vérifier vos réservations sur le site.\nMerci.\nCordialement.");
	    	Transport.send(message,"mouad.afathi@um5s.net.ma","king-flow");
	    	System.out.println("Sent message successfully....");
		} catch (MessagingException mex) {
			mex.printStackTrace();
		}
	}
	public void reserverOffre(int code, String type)
	{
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", "smtp.gmail.com");
	    properties.put("mail.smtp.starttls.enable","true"); 
	    properties.put("mail.smtp.EnableSSL.enable","true");
	    properties.put("mail.smtp.auth", "true");
	    properties.put("mail.smtp.port", 587);
	    
	    Session session = Session.getDefaultInstance(properties);
	    
	    try {
	    	System.out.println(getOfficeservices());
	    	Offre o = getOfficeservices().getOffer(code, type);
	    	String email = o.getTransporteur().getEmail();
	    	MimeMessage message = new MimeMessage(session);
	    	message.setFrom(new InternetAddress("mouad.afathi@um5s.com"));
	    	message.addRecipient(Message.RecipientType.TO,
                    new InternetAddress(email));
	    	message.setSubject("Confimation de votre réservation");
	    	message.setText("Vous avez une nouvelle reservation. Pour plus d'information veuillez vérifier vos réservations sur le site.\nMerci.\nCordialement.");
	    	Transport.send(message,"mouad.afathi@um5s.net.ma","king-flow");
	    	System.out.println("Sent message successfully....");
		} catch (MessagingException mex) {
			mex.printStackTrace();
		}
	}
	public void annulerReservation(int code)
	{
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", "smtp.gmail.com");
	    properties.put("mail.smtp.starttls.enable","true"); 
	    properties.put("mail.smtp.EnableSSL.enable","true");
	    properties.put("mail.smtp.auth", "true");
	    properties.put("mail.smtp.port", 587);
	    
	    Session session = Session.getDefaultInstance(properties);
	    
	    try {
	    	Reservation r = getOfficeservices().getReservation(code);
	    	System.out.println(r);
	    	String email = r.getOffre().getTransporteur().getEmail();
	    	MimeMessage message = new MimeMessage(session);
	    	message.setFrom(new InternetAddress("mouad.afathi@um5s.com"));
	    	message.addRecipient(Message.RecipientType.TO,
                    new InternetAddress(email));
	    	message.setSubject("Confimation de votre réservation");
	    	message.setText("Un client a annuler une réservation. Pour plus d'information veuillez vérifier vos réservations sur le site.\nMerci.\nCordialement.");
	    	Transport.send(message,"mouad.afathi@um5s.net.ma","à modifier");
	    	System.out.println("Sent message successfully....");
		} catch (MessagingException mex) {
			mex.printStackTrace();
		}
	}
}