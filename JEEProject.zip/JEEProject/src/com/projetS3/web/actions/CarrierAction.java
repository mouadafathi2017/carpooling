package com.projetS3.web.actions;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.HibernateException;

import com.projetS3.business.OfficeServices;
import com.projetS3.jpa.Client;
import com.projetS3.jpa.Compte;
import com.projetS3.jpa.Offre;
import com.projetS3.jpa.OffreCovoiturage;
import com.projetS3.jpa.OffreTransportDuBien;
import com.projetS3.jpa.Reservation;
import com.projetS3.jpa.Transporteur;


public class CarrierAction extends Action {
	public CarrierAction() {
		super();
	}

	public CarrierAction(OfficeServices officeservices) {
		super(officeservices);
	}
	
	public String authentification()
	{
		
		Transporteur carrier = getOfficeservices().authentificationTransporteur(getRequest().getParameter("user"), getRequest().getParameter("password"));
		if(carrier != null)
		{
			if (getRequest().getSession()!=null) {
				getRequest().getSession().invalidate();
			}
			HttpSession session = getRequest().getSession(true); 
			session.setAttribute("login",getRequest().getParameter("user"));
			session.setAttribute("password",getRequest().getParameter("password"));
			session.setAttribute("user",carrier);
			System.out.println("session crée");
			return "/HomeCarrier.jsp";
		}
		else{
			getRequest().setAttribute("Error", "Invalid password or username.");
			return "/Error.jsp";
		}
	}
	public String ajouterNewOffre(){
		Transporteur carrier = (Transporteur)getRequest().getSession().getAttribute("user");
		getOfficeservices().insererNewOffer(getRequest().getParameter("villedep"), getRequest().getParameter("villedest"), getRequest().getParameter("offer"), getRequest().getParameter("date"), getRequest().getParameter("time"),getRequest().getParameter("maxP"), getRequest().getParameter("prixP"), getRequest().getParameter("maxK"), getRequest().getParameter("prixK"), getRequest().getParameter("desc"), carrier);
		return "/HomeCarrier.jsp";
		}
	
	public String inscrire(){
		getOfficeservices().insererNewCarrier(getRequest().getParameter("lname"), getRequest().getParameter("fname"), getRequest().getParameter("birthday"), getRequest().getParameter("cin"),getRequest().getParameter("phone"),getRequest().getParameter("email"), getRequest().getParameter("type"), getRequest().getParameter("Vehicle"), getRequest().getParameter("user"), getRequest().getParameter("password"));
		return "/index.jsp";
	}
	public String listerReservation()
	{
		Transporteur transp = (Transporteur) getRequest().getSession().getAttribute("user");
		List<Reservation> list = getOfficeservices().ListerReservationCarrier(transp.getId());
		getRequest().setAttribute("listRes", list);
		return "/reservationsCarrier.jsp";
	}
	public String ListerOffres()
	{	
		try{
		Transporteur transp = (Transporteur) getRequest().getSession().getAttribute("user");
		List<Offre> list = (List<Offre>) getOfficeservices().listerOffresCarrier(transp.getId());
		getRequest().setAttribute("listOffre", list);
		return "/OffersCarrier.jsp";
		}catch(HibernateException e)
		{
			System.out.println(e.getMessage());
			getRequest().setAttribute("Error", e.getMessage());
			return "/Error.jsp";
		}
	}
	public String supprimerOffre()
	{
		int code = Integer.parseInt((String)getRequest().getParameter("codeoffre"));
		String type = getRequest().getParameter("type");
		getOfficeservices().supprimerOffreCarrier(code,type);
		return ListerOffres();
	}
	public String updateAccount()
	{
		Compte compte = ((Transporteur)getRequest().getSession().getAttribute("user")).getCompte();
		String login = getRequest().getParameter("user");
		String oldPass = getRequest().getParameter("ancienPass");
		String newPass = getRequest().getParameter("nvPass");
		String newPassC = getRequest().getParameter("nvPassC");
		if(!oldPass.equals(compte.getPassword())){
			getRequest().getSession().setAttribute("Error", "Ancien mot de passe incorrect");
			return "/Error.jsp";
		}
		if(!newPass.equals(newPassC))
		{
			getRequest().getSession().setAttribute("Error", "Les mots de passe que vous avez entré ne se ressemblent pas.");
			return "/Error.jsp";
		}
		compte.setUsername(login);
		compte.setPassword(newPass);
		getOfficeservices().modifierCompteClient(compte);
		return "/HomeCustomer.jsp";
	}
	public String updateOffre()
	{
		Offre offre = getOfficeservices().getOffer(Integer.parseInt(getRequest().getParameter("code")),getRequest().getParameter("type"));
		getRequest().setAttribute("offre", offre);
		return "/updateOffer.jsp";
	}
	public String modifierOffre()
	{
		try{
			Offre offre = getOfficeservices().getOffer(Integer.parseInt(getRequest().getParameter("code")),(String)getRequest().getParameter("type"));
			System.out.println(getRequest().getParameter("villedep"));
			offre.setVilleDeaprt((String)getRequest().getParameter("villedep"));
			offre.setVilleDestination((String)getRequest().getParameter("villedest"));
			offre.setDateVoyage((String)getRequest().getParameter("date"));
			offre.setHeure((String)getRequest().getParameter("time"));
			offre.setDescription((String)getRequest().getParameter("desc"));
			String type = getRequest().getParameter("type");
			if(type.equals("C"))
			{
				((OffreCovoiturage)offre).setPrixParPersonne(Float.parseFloat((String)getRequest().getParameter("prixP")));
				((OffreCovoiturage)offre).setMaxPersonne(Integer.parseInt((String)getRequest().getParameter("maxP")));
			}
			else{
				System.out.println(getRequest().getParameter("prixK"));
				((OffreTransportDuBien)offre).setPrixParKilo(Float.parseFloat((String)getRequest().getParameter("prixK")));
				((OffreTransportDuBien)offre).setMaxKilos(Float.parseFloat((String)getRequest().getParameter("maxK")));
			}
			getOfficeservices().updateOffer(offre);
			return "/Offers.jsp";
		}catch(HibernateException e){
			getRequest().setAttribute("Error", e.getMessage());
			return "/Error.jsp";
		}
	}
	public String accepterReservation()
	{
		MailAction mailaction = new MailAction(getOfficeservices());
		int code = Integer.parseInt(getRequest().getParameter("code"));
		if(getOfficeservices().acceptReservation(code)){
			mailaction.confirmReservation(getRequest().getParameter("email"));
			return "/resCarrier.jsp";
		}else{
			getRequest().setAttribute("Error", "Cannot Accept this Reservation");
			return "/Error";
		}
	}
	public String rejeterReservation()
	{
		MailAction mailaction = new MailAction(getOfficeservices());
		int code = Integer.parseInt(getRequest().getParameter("code"));
		String email = (String)getRequest().getParameter("email");
		if(getOfficeservices().rejectReservation(code)){
			mailaction.rejectReservation(email);
			return "/resCarrier.jsp";
		}else{
			getRequest().setAttribute("Error", "Cannot Reject this Reservation");
			return "/Error";
		}
	}
	public String getClient()
	{
		Client client = (Client)getOfficeservices().getClient(Integer.parseInt(getRequest().getParameter("code")));
		getRequest().setAttribute("client", client);
		return "/profile.jsp";
	}
}
