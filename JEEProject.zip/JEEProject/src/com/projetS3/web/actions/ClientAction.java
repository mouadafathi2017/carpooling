package com.projetS3.web.actions;

import java.util.List;

import javax.servlet.http.HttpSession;


import com.projetS3.business.OfficeServices;
import com.projetS3.jpa.*;

public class ClientAction extends Action{

	public ClientAction() {
		super();
	}

	public ClientAction(OfficeServices officeservices) {
		super(officeservices);
	}
	
	public String authentification()
	{
		System.out.println("here");
		Client client = getOfficeservices().authentificationClient(getRequest().getParameter("login"), getRequest().getParameter("password"));
		if(client != null)
		{
			if (getRequest().getSession()!=null) {
				getRequest().getSession().invalidate();
			}
			HttpSession session = getRequest().getSession(true);
			session.setAttribute("user", client);
			session.setAttribute("login",getRequest().getParameter("login"));
			session.setAttribute("password",getRequest().getParameter("password"));
			System.out.println("session crée");
			return "/HomeCustomer.jsp";
		}
		else
			return "/ErrorAuth.jsp";
	}
	
	
	public String chercherOffres()
	{
		List<Offre> list = getOfficeservices().listerOffreClient(getRequest().getParameter("villedep"), getRequest().getParameter("villedest"),
				getRequest().getParameter("select"), getRequest().getParameter("date"));
		if(list != null)
		{	
			getRequest().setAttribute("list_offres",list);
			if(list.get(0).getClass() == com.projetS3.jpa.OffreCovoiturage.class)
				return "/OffersList.jsp";
			else
				return "/OffersListTB.jsp";
		}
		else
			return "/error.jsp";
	}
	
	public String ListerOffres(String type)
	{
		List<Offre> list = getOfficeservices().listerOffres(type);
		if(list != null)
		{	
			getRequest().setAttribute("list_offres",list);
			if(list.get(0).getClass() == com.projetS3.jpa.OffreCovoiturage.class)
				return "/OffersList.jsp";
			else
				return "/OffersListTB.jsp";
		}
		else
			return "/error.jsp";
	}
	
	public String reserverOffreC()
	{
		Client client = getOfficeservices().authentificationClient((String)getRequest().getSession().getAttribute("login"),
				(String)getRequest().getSession().getAttribute("password"));
		getOfficeservices().nouvelleReservation(Integer.parseInt(getRequest().getParameter("codeoffre")), client, "covoiturage");
		MailAction mailaction = new MailAction(getOfficeservices());
		mailaction.reserverOffre(Integer.parseInt(getRequest().getParameter("codeoffre")), "C");
		return afficherReservation();
	}
	public String reserverOffreTB()
	{
		Client client = getOfficeservices().authentificationClient((String)getRequest().getSession().getAttribute("login"),
				(String)getRequest().getSession().getAttribute("password"));
		getOfficeservices().nouvelleReservation(Integer.parseInt(getRequest().getParameter("codeoffre")), client, "bien");
		MailAction mailaction = new MailAction(getOfficeservices());
		mailaction.reserverOffre(Integer.parseInt(getRequest().getParameter("codeoffre")), "TB");
		return afficherReservation();
	}
	public String afficherReservation()
	{
		Client client = getOfficeservices().authentificationClient((String)getRequest().getSession().getAttribute("login"),
				(String)getRequest().getSession().getAttribute("password"));
		List<Reservation> list = getOfficeservices().listerReservationClient(client.getId());
		if(list != null)
		{
			getRequest().setAttribute("list_res", list);
			return "/Reservations.jsp";
		}
		else
			return "/PasdeRes.jsp";
	}
	
	public String modifierCompte()
	{
		Compte compte = ((Client)getRequest().getSession().getAttribute("user")).getCompte();
		String login = getRequest().getParameter("login");
		String oldPass = getRequest().getParameter("ancienPass");
		String newPass = getRequest().getParameter("nvPass");
		String newPassC = getRequest().getParameter("nvPassC");
		if(!oldPass.equals(compte.getPassword())){
			getRequest().getSession().setAttribute("messageEr", "Ancien mot de passe incorrect");
			return "/Error.jsp";
		}
		if(!newPass.equals(newPassC))
		{
			getRequest().getSession().setAttribute("messageEr", "Les mots de passe que vous avez entré ne se ressemblent pas.");
			return "/Error.jsp";
		}
		compte.setUsername(login);
		compte.setPassword(newPass);
		getOfficeservices().modifierCompteClient(compte);
		return "/HomeCustomer.jsp";
	}
	public String inscrire(){
		getOfficeservices().insererNewClient(getRequest().getParameter("lname"), getRequest().getParameter("fname"), getRequest().getParameter("birthday"), getRequest().getParameter("cin"),getRequest().getParameter("phone"),getRequest().getParameter("email"), getRequest().getParameter("type"), getRequest().getParameter("user"), getRequest().getParameter("password"));
		return "/index.jsp";
	}
	public String annulerReservation()
	{
		MailAction mailaction = new MailAction(getOfficeservices());
		mailaction.annulerReservation(Integer.parseInt(getRequest().getParameter("code")));
		if(getOfficeservices().annulerReservation(Integer.parseInt(getRequest().getParameter("code")))){
			return "/afficherRes.jsp";
		}else{
			getRequest().setAttribute("Error", "Cannot cancel this reservation");
			return "/Error.jsp";
		}
	}
}
