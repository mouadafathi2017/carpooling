package com.projetS3.web.actions;

import javax.servlet.http.HttpServletRequest;

import com.projetS3.business.OfficeServices;


public class Action {

	private HttpServletRequest request;
	private OfficeServices officeservices;
	
	public Action() {
		// TODO Auto-generated constructor stub
	}

	public Action(OfficeServices officeServices) {
		
		this.officeservices = officeServices;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public OfficeServices getOfficeservices() {
		return this.officeservices;
	}

	public void setOfficeservices(OfficeServices officeservices) {
		this.officeservices = officeservices;
	}

	public void setStockService(OfficeServices officeServices) {
		this.officeservices = officeServices;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	
}
