package com.projetS3.web.actions;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.catalina.connector.Request;

import com.projetS3.business.OfficeServices;
import com.projetS3.jpa.Admin;
import com.projetS3.jpa.Client;
import com.projetS3.jpa.Compte;
import com.projetS3.jpa.Offre;
import com.projetS3.jpa.OffreCovoiturage;
import com.projetS3.jpa.OffreTransportDuBien;
import com.projetS3.jpa.Transporteur;

public class AdminAction extends Action{

	public AdminAction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdminAction(OfficeServices officeServices) {
		super(officeServices);
		// TODO Auto-generated constructor stub
	}

	public String authentification()
	{
		Admin admin = getOfficeservices().authentificationAdmin(getRequest().getParameter("user"), getRequest().getParameter("password"));
		if(admin != null)
		{
			if (getRequest().getSession()!=null) {
				getRequest().getSession().invalidate();
			}
			HttpSession session = getRequest().getSession(true); 
			session.setAttribute("admin", admin);
			session.setAttribute("user", getRequest().getParameter("user"));
			session.setAttribute("pass", getRequest().getParameter("password"));
			System.out.println("session crée");
			return "/home.jsp";
		}
		else
			return "/ErrorAuth.jsp";
	}
	public String afficherOffre(String offre){
		if(offre.equals("listoffreCovoiturage")){
			
	       List<Offre> L=getOfficeservices().afficherOffreCovoiturage() ;
       	getRequest().setAttribute("Offrecovoiturage", L);
		   return "/listoffreCovoiturage.jsp";
	       }
		else{System.out.println("methode");
			List<Offre> L=getOfficeservices().afficherOffreTransport();
			getRequest().setAttribute("OffreTransport", L);
		    return "/listoffreTransportDuBien.jsp";
	}
	}
	
	
	public String afficherPersonne(String personne ){
		if(personne.equals("Client")){
			
	       List<Client> L=getOfficeservices().afficherClient() ;
	   	getRequest().setAttribute("Client", L);
		   return "/listclient.jsp";
	       }
		else{
			List<Transporteur> L=getOfficeservices().afficherTransporteur();
			getRequest().setAttribute("Transporteur", L);
		    return "/listTransporteur.jsp";
	}
	}
	public String SuppressionOffreTransport(){
		getOfficeservices().deleteOffretransport(Integer.parseInt(getRequest().getParameter("code")));
		return "/home.jsp";
	}
	
	public String SuppressionOffreCovoiturage(){
		getOfficeservices().deleteOffreCovoiturage((Integer.parseInt(getRequest().getParameter("code"))));
		return "/home.jsp";
	}
	public String SuppressionClient(){
		getOfficeservices().deleteClient((Integer.parseInt(getRequest().getParameter("code"))));
		return "/home.jsp";
	}
	public String SuppressionTransporteur(){
		getOfficeservices().deleteTransporteur(((Integer.parseInt(getRequest().getParameter("code")))));
		return "/home.jsp";
	}

	public String modificationOffreCovoiturage(){
		OffreCovoiturage offreC=getOfficeservices().afficheOffreCovoiturage((Integer.parseInt(getRequest().getParameter("code"))));
		offreC.setVilleDeaprt(getRequest().getParameter("villedep"));
		offreC.setVilleDestination(getRequest().getParameter("villedest"));
		offreC.setDateVoyage(getRequest().getParameter("date"));
		offreC.setDescription(getRequest().getParameter("desc"));
		offreC.setPrixParPersonne((Float.parseFloat( getRequest().getParameter("prixP"))));
		offreC.setPrixParPersonne((Integer.parseInt( getRequest().getParameter("maxP"))));
		getOfficeservices().updateOffreCovoiturage(offreC);
		return "/home.jsp";
		}
	 public String affichage_OffreCovoiturage(){
		 OffreCovoiturage c=getOfficeservices().afficheOffreCovoiturage((Integer.parseInt(getRequest().getParameter("code"))));
		getRequest().setAttribute("Offrecovoiturage", c);
			return "/modify_offreCovoiturage.jsp";
	 }
	 public String modificationProfil(){
			int id = Integer.parseInt(getRequest().getParameter("code"));
			Admin adminSite = getOfficeservices().afficheAdmin(id);
		    Compte compte= adminSite.getCompte();
			adminSite.setNom(getRequest().getParameter("fname"));
			adminSite.setPrenom(getRequest().getParameter("lname"));
			adminSite.setDateNaissance(getRequest().getParameter("birthday"));
			adminSite.setCin(getRequest().getParameter("phone"));
			adminSite.setEmail( getRequest().getParameter("email"));
			compte.setPassword(getRequest().getParameter("password"));
			getOfficeservices().ModifierProfil(adminSite);
			getOfficeservices().ModifierCompte(compte);
			return "/home.jsp";
			}
	 public String affichage_Profil(){
		 Admin ad = (Admin)getRequest().getSession().getAttribute("admin");
		 Admin adm=getOfficeservices().afficheAdmin(ad.getId());
		 getRequest().setAttribute("Admin",adm);
		 return "/monProfil.jsp";
	 }
	
}
