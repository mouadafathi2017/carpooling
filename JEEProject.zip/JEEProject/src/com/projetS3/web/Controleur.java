package com.projetS3.web;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import com.projetS3.business.DefaultOfficeServices;
import com.projetS3.business.OfficeServices;
import com.projetS3.dao.AdminDao;
import com.projetS3.dao.AdminDaoJdbc;
import com.projetS3.dao.ClientDao;
import com.projetS3.dao.ClientDaoJdbc;
import com.projetS3.dao.CompteDao;
import com.projetS3.dao.CompteDaoJdbc;
import com.projetS3.dao.OffreCovoiturageDao;
import com.projetS3.dao.OffreCovoiturageDaoJdbc;
import com.projetS3.dao.OffreTransportDuBienDao;
import com.projetS3.dao.OffreTransportDuBienDaoJdbc;
import com.projetS3.dao.ReservationDao;
import com.projetS3.dao.ReservationDaoJdbc;
import com.projetS3.dao.TransporteurDao;
import com.projetS3.dao.TransporteurDaoJdbc;
import com.projetS3.utils.HibernateUtils;
import com.projetS3.web.actions.AdminAction;
import com.projetS3.web.actions.CarrierAction;
import com.projetS3.web.actions.ClientAction;
import com.projetS3.web.actions.MailAction;

import sun.nio.cs.HistoricallyNamedCharset;

public class Controleur extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	private static Session session;
	
	private AdminDao admindao;
	private ClientDao clientdao;
	private CompteDao comptedao;
	private OffreCovoiturageDao offreCovoituragedao;
	private OffreTransportDuBienDao offreTransportDuBiendao;
	private ReservationDao reservationdao;
	private TransporteurDao transporteurdao;
	
	private OfficeServices officeservices;
	
	private MailAction mailaction;
	private ClientAction clientaction;
	private CarrierAction carrieraction;
	private AdminAction adminaction;
	
	public Controleur()
	{
	}
	
	public void init(ServletConfig config) throws ServletException {
		session = HibernateUtils.getSession();
		
		admindao = new AdminDaoJdbc(session);
		offreCovoituragedao = new OffreCovoiturageDaoJdbc(session);
		offreTransportDuBiendao = new OffreTransportDuBienDaoJdbc(session);
		reservationdao = new ReservationDaoJdbc(session);
		transporteurdao = new TransporteurDaoJdbc(session);
		clientdao = new ClientDaoJdbc(session);
		comptedao = new CompteDaoJdbc(session);
		
		officeservices = new DefaultOfficeServices(admindao, clientdao, comptedao, offreCovoituragedao, offreTransportDuBiendao, reservationdao, transporteurdao);
		
		clientaction = new ClientAction(officeservices);
		mailaction = new MailAction(officeservices);
		carrieraction = new CarrierAction(officeservices);
		adminaction = new AdminAction(officeservices);
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String view="";
		String uri = request.getRequestURI();

		int i = uri.lastIndexOf('/') + 1;
		int j = uri.lastIndexOf('.');
		String key = uri.substring(i, j);
		
		
		
		System.out.println(uri);
		switch (key) {
			case "sendMsg" :
				mailaction.setRequest(request);
				mailaction.send();
				view="/contact.jsp";
				break;
			case "loginCustomer" :
				clientaction.setRequest(request);
				view = clientaction.authentification();
				break;
			case "loginCarrier" :
				carrieraction.setRequest(request);
				view = carrieraction.authentification();
				break;
			case "searchWay" :
				clientaction.setRequest(request);
				view = clientaction.chercherOffres();
				break;
			case "reserver" :
				clientaction.setRequest(request);
				view = clientaction.reserverOffreC();
				break;
			case "reserverT" :
				clientaction.setRequest(request);
				view = clientaction.reserverOffreTB();
				break;
			case "modifyCustomer" :
				clientaction.setRequest(request);
				view = clientaction.modifierCompte();
				break;
			case "OffersTB" :
				clientaction.setRequest(request);
				view = clientaction.ListerOffres("bien");
				break;
			case "OffersC" :
				clientaction.setRequest(request);
				view = clientaction.ListerOffres("covoiturage");
				break;
			case "afficherRes" :
				clientaction.setRequest(request);
				view = clientaction.afficherReservation();
				break;
			case "newOffer" :	
				carrieraction.setRequest(request);
				view= carrieraction.ajouterNewOffre();
				break;
			case"registerCarrier1" :
				carrieraction.setRequest(request);
				view= carrieraction.inscrire();
				break;
			case"registerCustomer" :
				clientaction.setRequest(request);
				view= clientaction.inscrire();
				break;
			case "loginAdmin" :
				adminaction.setRequest(request);
				view = adminaction.authentification();
				break;
			case "resCarrier" :
				carrieraction.setRequest(request);
				view = carrieraction.listerReservation();
				break;
			case "Offers" :
				carrieraction.setRequest(request);
				view = carrieraction.ListerOffres();
				break;
			case "modifyoffre" :
				carrieraction.setRequest(request);
				view = carrieraction.updateOffre();
				break;
			case "deleteoffre" :
				carrieraction.setRequest(request);
				view = carrieraction.supprimerOffre();
				break;
			case "upOffre" :
				carrieraction.setRequest(request);
				view = carrieraction.modifierOffre();
				break;
			case "modifyCarrier" :
				carrieraction.setRequest(request);
				view = carrieraction.updateAccount();
				break;
			case "accept" :
				carrieraction.setRequest(request);
				view = carrieraction.accepterReservation();
				break;
			case "reject" :
				carrieraction.setRequest(request);
				view = carrieraction.rejeterReservation();
				break;
			case "annuler" :
				clientaction.setRequest(request);
				view = clientaction.annulerReservation();
				break;
			case "showProfile" :
				carrieraction.setRequest(request);
				view = carrieraction.getClient();
				break;
			case"listCovoiturage"	:
				adminaction.setRequest(request);
				view=adminaction.afficherOffre("listoffreCovoiturage");
				break;
			case"listTransportDuBien"	:
				
				adminaction.setRequest(request);
				view=adminaction.afficherOffre("listoffreTransportDuBien");
				break;
			case"Client"	:
				adminaction.setRequest(request);
				view=adminaction.afficherPersonne("Client");
				break;
			case"Transporteur"	:
				adminaction.setRequest(request);
				view=adminaction.afficherPersonne("Transporteur");
				break;
	       case"delete_offretransport":
		      adminaction.setRequest(request);
		      view=adminaction.SuppressionOffreTransport();
		      break;
	       case"delete_offreCovoiturage":
			      adminaction.setRequest(request);
			      view=adminaction.SuppressionOffreCovoiturage();
			      break;
	       case"deleteClient":
			      adminaction.setRequest(request);
			      view=adminaction.SuppressionClient();
			      break;
	       case"deleteTransporteur":
			      adminaction.setRequest(request);
			      view=adminaction.SuppressionTransporteur();
			      break;
	       case"AfficheOffreCovoiturage":
			      adminaction.setRequest(request);
			      view=adminaction.affichage_OffreCovoiturage();
			      break;
	       case"updateOffreCovoiturage":
			      adminaction.setRequest(request);
			      view=adminaction.modificationOffreCovoiturage();
			      break;
	       case"AfficherMonProfil":
			      adminaction.setRequest(request);
			      view=adminaction.affichage_Profil();
			      break;
	       case"ModifyProfil" :
	    	   adminaction.setRequest(request);
			      view=adminaction.modificationProfil();
			      break;
			case "logout" :
				request.getSession().invalidate();
				view = "/index.jsp";
				break;
		}
		request.getServletContext().getRequestDispatcher(view).forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}